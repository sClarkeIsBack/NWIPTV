import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLm53aXB0dg==')

name = b.b64decode('Tm9ydGggV2VzdCBJUFRW')

host = b.b64decode('aHR0cDovL2ZsYXdsZXNzLWlwdHYubmV0')

port = b.b64decode('NDU0NQ==')